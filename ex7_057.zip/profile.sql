create database profile;
use profile;

create or replace table profile_details(
    userid int(5),
    name varchar(30),
    uname varchar(20),
    password varchar(30),
    phone varchar(10)
    );

desc profile_details;

insert into profile_details values(12608,'Krithika','admin','password',8927387232);

select * from profile_details;