import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class ProfileServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Initialize all the information regarding Database Connection
        String dbDriver = "com.mysql.jdbc.Driver";
        String dbURL = "jdbc:mysql://localhost:3306/";
        // Database
        String dbName = "profile";
        String dbUsername = "root";
        String dbPassword = "admin";
        
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try{
            
            Class.forName(dbDriver);
            Connection conn = DriverManager.getConnection(dbURL + dbName,
                                                     dbUsername, 
                                                     dbPassword);
            
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("select * from profile_details");
            
            HttpSession session = request.getSession(false);
            String user = (String)session.getAttribute("uname");
            String sid = session.getId();
            
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ProfileServlet</title>"); 
            out.println("<style>");
            out.println("""
                        table{
                            border: 2px solid black;
                            border-collapse: collapse;
                            padding: 5px;
                        }
                        th{
                            font-weight: 800;
                            border-right: 2px solid black;
                            border-bottom: 2px solid black;
                            padding: 5px;
                        }
                        td{
                            border-right: 2px solid black;
                            padding: 5px;
                        }
                        """);
            out.println("</style>");
            out.println("</head>");
            out.println("<body>");
            out.println("Welcome " + user + " to the profile page!");
            out.println("<h1>Profile Details: </h1>");
            out.println("<table>");
            out.println("<tr> <th>USER ID</th> <th>NAME</th> <th>USERNAME</th> <th>PASSWORD</th> <th>PHONE NO.</th> </tr>");
            while(rs.next()){
                out.println("<tr>");
                out.println("<td>" + rs.getInt(1) + "</td>");
                out.println("<td>" + rs.getString(2) + "</td>");
                out.println("<td>" + rs.getString(3) + "</td>");
                out.println("<td>" + rs.getString(4) + "</td>");
                out.println("<td>" + rs.getString(5) + "</td>");
                out.println("</tr>");
            }
            out.println("</table>");
            out.println("<br>");
            out.println("Session ID: " + sid);
            out.println("<br>");
            out.println("Session name: " + user);
            out.println("<br>");
            out.println("<br>");
            out.println("""
                        <div>
                            <form id="viewform" method="post" action="http://localhost:8080/profile/login.html" target="_blank">
                                <button type="submit" id="viewbutton" value="view">Go to Login page</button>
                                <br>
                                <button type=\"submit\" id=\"logoutbutton\" value=\"logout\" formaction=\"http://localhost:8080/profile/LogoutServlet\" formtarget=\"_self\">Log out</button>
                            </form>
                        </div>
                        """);
            out.println("</body>");
            out.println("</html>");
        }
        catch(SQLException se){
            out.println("SQL Exception! Something went wrong on the database side. Please try again!");
        }
        catch(Exception e){
            out.println("Something went wrong! Please try again.");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
