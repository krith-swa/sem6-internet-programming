import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class LoginServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Initialize all the information regarding Database Connection
        String dbDriver = "com.mysql.jdbc.Driver";
        String dbURL = "jdbc:mysql://localhost:3306/";
        // Database
        String dbName = "profile";
        String dbUsername = "root";
        String dbPassword = "admin";
        
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        try{
            
            Class.forName(dbDriver);
            Connection conn = DriverManager.getConnection(dbURL + dbName,
                                                     dbUsername, 
                                                     dbPassword);
            
            HttpSession session = request.getSession();
            
            String uname = request.getParameter("uname");
            session.setAttribute("uname", uname);
            
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet LoginServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("Welcome, " + uname + "!");
            out.println("<br>");
            out.println("""
                        <div>
                            <form id="viewform" method="post" action="http://localhost:8080/profile/ProfileServlet" target="_blank">
                                <button type="submit" id="viewbutton" value="view">View Profile in Detail</button>
                                <br>
                                <button type=\"submit\" id=\"logoutbutton\" value=\"logout\" formaction=\"http://localhost:8080/profile/LogoutServlet\" formtarget=\"_self\">Log out</button>
                            </form>
                        </div>
                        """);
            out.println("</body>");
            out.println("</html>");
        }
        catch(SQLException se){
            out.println("SQL Exception! Something went wrong on the database side. Please try again!");
        }
        catch(Exception e){
            out.println("Something went wrong! Please try again.");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
