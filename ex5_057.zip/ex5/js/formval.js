function checkSalutation() {
    var salutation=document.querySelector('input[name="salutation"]:checked');
    if (salutation==null)
    {
        document.getElementById("error_sal").innerHTML="A salutation is required!"; 
        document.getElementById("dr").focus();
        return false;
    }
    else {
        document.getElementById("error_sal").innerHTML=""; 
        return true;
    }
}

function checkName() {
    var name = document.getElementById("name").value;
    if (name.length > 0) {
        var expr = /^[A-Z] [A-Za-z]+ ?([A-Za-z]*)?$/;
        if (name.match(expr)) {
            document.getElementById("error_name").innerHTML="";
            return true;
        }
        else {
            document.getElementById("error_name").innerHTML="Invalid name! Required: Initial FirstName LastName";
            return false;
        }
    }
    else {
        document.getElementById("error_name").innerHTML="Name must not be empty!";
        return false;
    }
}

function checkUsername() {
    var uname = document.getElementById("uname").value;
    if (uname.length > 0) {
        var expr = /^[A-Za-z]+$/;
        if (uname.match(expr)) {
            document.getElementById("error_uname").innerHTML="";
            return true;
        }
        else {
            document.getElementById("error_uname").innerHTML="Invalid username! Must only contain letters from the English alphabet!";
            return false;
        }
    }
    else {
        document.getElementById("error_uname").innerHTML="Username must not be empty!";
        return false;
    }
}

function checkPassword() {
    var pwd = document.getElementById("pwd").value;
    if (pwd.length > 0) {
        var expr = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[~`!@#$%^&*'])[A-Za-z0-9@$!%*?&]{8,}$/;
        if (uname.match(expr)) {
            document.getElementById("error_pwd").innerHTML="";
            return true;
        }
        else {
            document.getElementById("error_pwd").innerHTML="Invalid password!";
            return false;
        }
    }
    else {
        document.getElementById("error_pwd").innerHTML="Password must not be empty!";
        return false;
    }
}

function checkEmail() {
    var email = document.getElementById("email").value;
    if (email.length > 0) {
        var expr = /^[a-zA-Z0-9_]+@[a-zA-Z0-9.-]+.[a-zA-Z]{2,3}$/;
        if (email.match(expr)) {
            document.getElementById("error_email").innerHTML="";
            return true;
        }
        else {
            document.getElementById("error_email").innerHTML="Invalid email!";
            return false;
        }
    }
    else {
        document.getElementById("error_email").innerHTML="Email must not be empty!";
        return false;
    }
}

function checkDob(event) {
    var dob = new Date(document.getElementById("dob").value);
    if(!isNaN(Date.parse(dob))) {
        var difference = Date.now() - dob.getTime(); 
        var ageDate = new Date(difference); 
        var calculatedAge= Math.abs(ageDate.getUTCFullYear() - 1970);
        if (calculatedAge<18 || calculatedAge>35) {
            document.getElementById("error_dob").innerHTML="Invalid age! Must be of 18-25 years of age!"
            document.getElementById("dob").focus();
            event.preventDefault();
            return false;
        }
        else {
            document.getElementById("error_dob").innerHTML="";
            return true;
        }
    }
    else {
        document.getElementById("error_dob").innerHTML="DoB must not be empty!";
        return false;
    }
}

function checkPhoto() {
    var photo = document.getElementById("photo").value;
    if (photo != "") {
        document.getElementById("error_photo").innerHTML="";
        return true;
    }
    else {
        document.getElementById("error_photo").innerHTML="Please upload the required photo!";
        return false;
    }
}

function checkLang() {
    var known_lang = document.getElementsByClassName("lang");
    var count = 0;
    for (var i=0; i<6; i++) {
        if (known_lang[i].checked) {
            count = count+1;
        }
    }
    if (count < 2) {
        document.getElementById("error_lang").innerHTML="Please choose at least 2 languages!";
        document.getElementById("lang1").focus();
        count = 0;
        return false;
    }
    else {
        document.getElementById("error_lang").innerHTML="";
        return true;
    }
}

function fill_lang() {
    var other = document.getElementById("other_lang");
    if (document.getElementById("lang6").checked) {
        other.style.display='block';
        other.style.height='26px';
        other.style.width='20%';
        other.style.margin='10px';
    }
    else {
        other.style.display='none';
    }
}

function checkAddExp() {
    var addexp = document.getElementById("addexp").value;
    if (addexp.length > 0) {
        document.getElementById("error_addexp").innerHTML="";
        return true;    
    }
    else {
        document.getElementById("error_addexp").innerHTML="Please enter the details of any additional expertise you have!";
        document.getElementById("addexp").focus();
        return false;
    }
}

function formValidate() {
    if (checkSalutation() && checkName() && checkUsername() && checkPassword() && checkEmail() && checkDob(e) && checkPhoto() && checkLang() && checkAddExp()){
        alert("Registration successful!")
        return true;
    }
    else
        return false;
}

function clearAll() {
    var err = document.getElementsByClassName("error");
    for (var i=0; i<err.length; i++){
        err[i].innerHTML="";
    }
}