import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

/**
 *
 * @author Krithika Swaminathan
 */
public class ViewServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Initialize all the information regarding Database Connection
        String dbDriver = "com.mysql.jdbc.Driver";
        String dbURL = "jdbc:mysql://localhost:3306/";
        // Database
        String dbName = "pms";
        String dbUsername = "root";
        String dbPassword = "admin";
        
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try{
            
            Class.forName(dbDriver);
            Connection conn = DriverManager.getConnection(dbURL + dbName,
                                                     dbUsername, 
                                                     dbPassword);
            
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("select * from patient_details");
            
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ViewServlet</title>");    
            out.println("<style>");
            out.println("""
                        table{
                            border: 2px solid black;
                            border-collapse: collapse;
                            padding: 5px;
                        }
                        th{
                            font-weight: 800;
                            border-right: 2px solid black;
                            border-bottom: 2px solid black;
                            padding: 5px;
                        }
                        td{
                            border-right: 2px solid black;
                            padding: 5px;
                        }
                        """);
            out.println("</style>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Patient Details: </h1>");
            out.println("<table>");
            out.println("<tr> <th>NAME</th> <th>AGE</th> <th>ID</th> <th>GENDER</th> <th>ADDRESS</th> <th>MARITAL STATUS</th> <th>DATE OF VISIT</th> <th>DISEASE NAME</th> </tr>");
            while(rs.next()){
                out.println("<tr>");
                out.println("<td>" + rs.getString(1) + "</td>");
                out.println("<td>" + rs.getInt(2) + "</td>");
                out.println("<td>" + rs.getInt(3) + "</td>");
                out.println("<td>" + rs.getString(4) + "</td>");
                out.println("<td>" + rs.getString(5) + "</td>");
                out.println("<td>" + rs.getString(6) + "</td>");
                out.println("<td>" + rs.getString(7) + "</td>");
                out.println("<td>" + rs.getString(8) + "</td>");
                out.println("</tr>");
            }
            out.println("</table>");
            out.println("</body>");
            out.println("</html>");
            
            rs.close();
            st.close();
            conn.close();
        }
        catch(SQLException se){
            out.println("SQL Exception! Something went wrong on the database side. Please try again!");
        }
        catch(Exception e){
            out.println("Something went wrong! Please try again.");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
