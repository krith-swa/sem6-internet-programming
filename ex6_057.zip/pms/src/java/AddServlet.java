import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

/**
 *
 * @author Krithika Swaminathan
 */
public class AddServlet extends HttpServlet {

    @SuppressWarnings("UseSpecificCatch")
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Initialize all the information regarding Database Connection
        String dbDriver = "com.mysql.jdbc.Driver";
        String dbURL = "jdbc:mysql://localhost:3306/";
        // Database
        String dbName = "pms";
        String dbUsername = "root";
        String dbPassword = "admin";
        
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try{
            
            Class.forName(dbDriver);
            Connection conn = DriverManager.getConnection(dbURL + dbName,
                                                     dbUsername, 
                                                     dbPassword);
            
            PreparedStatement ps = conn.prepareStatement("insert into patient_details values(?,?,?,?,?,?,?,?)");
            ps.setString(1,request.getParameter("name"));
            ps.setInt(2,Integer.parseInt(request.getParameter("age")));
            ps.setInt(3, Integer.parseInt(request.getParameter("pid")));
            ps.setString(4,request.getParameter("gender"));
            ps.setString(5,request.getParameter("addr"));
            ps.setString(6,request.getParameter("mar_stat"));
            ps.setString(7,request.getParameter("dov"));
            ps.setString(8,request.getParameter("disease"));
            
            ps.executeUpdate();
            ps.close();
            conn.close();
            
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet AddServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("Record added!");
            out.println("<br>");
            out.println("""
                        <div>
                            <form id="viewform" method="post" action="http://localhost:8080/pms/ViewServlet" target="_blank">
                                <button type="submit" id="viewbutton" value="view">View Patient Details</button>
                            </form>
                        </div>
                        """);
            out.println("</body>");
            out.println("</html>");
        }
        catch(SQLException se){
            out.println("SQL Exception! Something went wrong on the database side. Please try again!");
        }
        catch(Exception e){
            out.println("Something went wrong! Please try again.");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
