import './App.css';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Layout from "./pages/Layout";
import Home from "./pages/Home";
import Committee from "./pages/Committee";
import Papers from "./pages/Papers";
import Dates from "./pages/Dates";
import Workshops from "./pages/Workshops";
import Registration from "./pages/Registration";
import Contact from "./pages/Contact";

function App() {
  return (
    <div className="App">
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Layout />}>
              <Route index element={<Home />} />
              <Route path="committee" element={<Committee />} />
              <Route path="papers" element={<Papers />} />
              <Route path="dates" element={<Dates />} />
              <Route path="workshops" element={<Workshops />} />
              <Route path="registration" element={<Registration />} />
              <Route path="contact" element={<Contact />} />
            </Route>
          </Routes>
        </BrowserRouter>
    </div>
  );
}

export default App;
