import React from 'react';

function Registration() {
    return (
        <div>
                <div id="heading">
                    <center><h1>INTERNATIONAL CONFERENCE ON PHYSICS AND ITS APPLICATIONS</h1></center>
                    <center><h1>May 3 - 5, 2023 Chennai, India</h1></center>
                </div>
    
                <section class="section">
                    <div class="box-main">          
                        <div class="firstHalf">
                            <h1 class="text-big">
                                Registration
                            </h1>
                            <p class="text-small">
                                Welcome to the Registraions page!
                            </p>
                        </div>
                    </div>
                </section>
        </div>
    );
}

export default Registration;
