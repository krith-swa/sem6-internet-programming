import React from 'react';

function Home() {
  return (
    <div>
            <div id="heading">
                <center><h1>INTERNATIONAL CONFERENCE ON PHYSICS AND ITS APPLICATIONS</h1></center>
                <center><h1>May 3 - 5, 2023 Chennai, India</h1></center>
            </div>

			<section class="section">
				<div class="box-main">          
					<div class="firstHalf">
						<h1 class="text-big">
							About
						</h1>
						<p class="text-small">
							United Nations Scientific Group, a non-profit organization takes the privilege to invite you to the 28<sup>th</sup> 
              International Conference on Physics and Its Applications (Physics-2023) which will be held on May 3-5, 2023 at Chennai, India. 
              Physics-2023 hosts an important gathering and fosters connections that will spur the innovations in the field of Physics.
						</p>
					</div>
				</div>
			</section>
			<section class="section">
				<div class="box-main">
					<div class="secondHalf">
						<h1 class="text-big" id="program">
							Agenda
						</h1>
						<p class="text-small">
            The agenda of the conference is to bring together all the devoted scholars, students, expert speakers and policy makers to share and discuss advances and developments in the field of Physics. 
            It is a three-day event which features physics experts, academicians, business executives and engineers to showcase recent trends, strategies and challenges.
						</p>
					</div>
				</div>
			</section>
			<section class="section">
				<div class="box-main">
					<div class="secondHalf">
						<h1 class="text-big" id="program">
							Importance of the Conference
						</h1>
						<p class="text-small">
            The three-day conference will feature important presentations by a wide range of expert speakers, policy makers, and scientific leaders from around the world. 
            It aims to foster international scientific networking and cooperation.
						</p>
					</div>
				</div>
			</section>
			<section class="section">
				<div class="box-main">
					<div class="secondHalf">
						<h1 class="text-big" id="program">
							What is Physics?
						</h1>
						<p class="text-small">
            Physics is the branch of science concerned with the nature and properties of matter and energy. 
            The subject matter of physics includes mechanics, heat, light and other radiation, sound, electricity, magnetism, and the structure of atoms.
						</p>
					</div>
				</div>
			</section>
    </div>
  );
}

export default Home;
