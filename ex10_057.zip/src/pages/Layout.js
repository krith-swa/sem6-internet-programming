import React from 'react';
import { Outlet, Link } from "react-router-dom";

function Layout() {
  return (
    <div>
			<nav class="navbar background">
				<ul class="nav-list">
					<div class="logo">
						<img src="images/atom1.jpg" alt="logo" />
					</div>
					<li> <Link to="/">HOME</Link> </li>
                    <li> <Link to="/committee">COMMITTEE</Link> </li>
                    <li> <Link to="/papers">CALL FOR PAPERS</Link> </li>
                    <li> <Link to="/dates">DATES</Link> </li>
                    <li> <Link to="/workshops">WORKSHOPS</Link> </li>
                    <li> <Link to="/registration">REGISTRAION</Link> </li>
                    <li> <Link to="/contact">CONTACT</Link> </li>
				</ul>

				<div class="rightNav">
					
				</div>
			</nav>

            <Outlet />

            <footer className="footer">
				<p className="text-footer">
					Copyright © (2023-present) by Krithika Swaminathan - All rights are reserved.
				</p>
                <p className="text-footer">
                Contact: &nbsp; <a href="mailto:krithika2010039@ssn.edu.in"> krithika2010039@ssn.edu.in</a>
                </p>
            </footer>
		</div>
  );
}

export default Layout;
