const http = require('http');

const server = http.createServer((req, res) => {

    const books = [
        { title: 'The Origin of Species', author: 'Charles Darwin' },
        { title: 'Six of Crows', author: 'Leigh Bardugo' },
        { title: 'Swami and Friends', author: 'R K Narayan' },
        { title: 'The Mark of Athena', author: 'Rick Riordan' },
        { title: 'Pride and Prejudice', author: 'Jane Austen' },
        { title: 'Anne of Green Gables', author: 'L M Montgomery' },
        { title: 'Black Beauty', author: 'Anna Swell' },
    ];
  
    const html = `
        <html>
        <head>
            <title>Books</title>
            <style>
                table, th, td {
                    margin: 0 auto;
                    border: 1px solid black;
                    border-collapse: collapse;
                    font-size: 18px;
                }
                td {
                    padding: 10px; 
                }
            </style>
        </head>
        <body>
            <center><h1>List of Books</h1></center>
            <table>
            <tr>
                <th>Title</th>
                <th>Author</th>
            </tr>
            ${books.map(book => `
                <tr>
                <td>${book.title}</td>
                <td>${book.author}</td>
                </tr>
            `).join('')}
            </table>
        </body>
        </html>
    `;
    res.setHeader('Content-Type', 'text/html');
    res.write(html);
    res.end();
});

// Start the server and listen for requests on port 3000
server.listen(3000, () => {
  console.log('Server is listening on http://localhost:3000');
});