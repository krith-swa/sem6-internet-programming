const fs = require('fs');
const rl = require('readline');

fs.readFile('greetings.txt', 'utf-8', function(err,data) {
    if (err) {
        console.error("Error in reading the file!");
        return;
    }

    const greetings = data.trim().split('\r\n');
    if (greetings.length == 0) {
        console.error('No greetings found!\n');
        return;
    }

    const rli = rl.createInterface({
        input: process.stdin,
        output: process.stdout,
    });

    rli.question(`What's your name? - `, name => {
        rli.close();
        const index = Math.floor(Math.random()*greetings.length);
        const greeting = greetings[index];
        console.log(greeting + ", " + name + "!");
    });
});

console.log('This program has susccessfully completed execution!\n');