const http = require('http');
const url = require('url');
const fs = require('fs');

fs.readFile('greetings.txt', 'utf8', (err, data) => {
    if (err) {
        console.error("Error in reading the file!", err);
        return;
    }

    const greetings = data.trim().split('\r\n');
    if (greetings.length == 0) {
        console.error('No greetings found!\n');
        return;
    }

    const server = http.createServer((req, res) => {
        const query = url.parse(req.url, true).query;
        var name = query.name;
        if (!name) {
            name=undefined;
        } 
        const index = Math.floor(Math.random()*greetings.length);
        const greeting = greetings[index];
        var greet_name = greeting.concat(", " + name + "!");
        res.writeHead(200, { 'Content-Type': 'text/plain' });
        res.end(greet_name);
    });

    // Start server listening on port 8088
    server.listen(8080, () => {
        console.log('Server started on http://localhost:8080');
    });
});