const { MongoClient } = require('mongodb');

const uri = "mongodb+srv://krithika:password268@mycluster.w7hd63a.mongodb.net/patient_details?retryWrites=true&w=majority";
const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });

async function main() {
  try {
    await client.connect();
    console.log("Connected to MongoDB");

    const db = client.db("patient_details");

    // Add operation
    const patientToAdd = {
      name: 'Bob',
      age: 30,
      id: 'P002',
      gender: 'M',
      address: 'Bangalore',
      marital_status: 'married',
      date_of_visit: '24/03/2023'
    };
    const result = await db.collection('patient_details').insertOne(patientToAdd);
    console.log(`Added ${result.insertedCount} new patient record with ID ${result.insertedId}`);

    // Delete operation
    const deleteResult = await db.collection('patient_details').deleteOne({ id: 'P001' });
    console.log(`Deleted ${deleteResult.deletedCount} patient record`);

    // Update operation
    const updateResult = await db.collection('patient_details').updateOne(
      { id: 'P002' },
      { $set: { address: 'Mumbai' } }
    );
    console.log(`Updated ${updateResult.modifiedCount} patient record`);

    // Search operation
    const searchResult = await db.collection('patient_details').findOne({ id: 'P002' });
    console.log(`Found patient record:`, searchResult);

  } catch (err) {
    console.error(err);
  } finally {
    await client.close();
    console.log("Disconnected from MongoDB");
  }
}

main().catch(console.error);
